create database Diabetes;
use Diabetes;
create table Info(
Pregnancies int,
Glucose int,
BloodPressure int,
Insulin int,
BMI int,
DiabetesPedigreeFunction float,
Age int,
Outcome int)

select * from Info;